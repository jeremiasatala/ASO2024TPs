#!/bin/bash
numeroObjetivo=$(($RANDOM%100))
logrado=0

echo "Hola profe, queres timbear un poco?"
while [ $logrado -eq 0 ];
do
    echo "Decime un numero entre el 1 y el 100"
    read numeroIngresado
    if [ "$numeroIngresado" -gt "$numeroObjetivo" ];
    then
        echo "Muy alto!"
    elif [ "$numeroIngresado" -lt "$numeroObjetivo" ];
    then
        echo "Muy bajo!"
    else
        echo "Muy bien profe! No me aprobas?"
        logrado=1
    fi
done