#!/bin/bash
logrado=0
echo "Hola profe, queres averiguar el genero de un nombre?"

while [ $logrado -eq 0 ];
do
    echo "Ingresa un nombre:"
    read nombre
    url="https://api.genderize.io/?name=${nombre}"
    response=$(curl -s "$url")

    if [ $? -eq 0 ]; then
        genero=$(echo "$response" | jq -r '.gender')

        if [ "$genero" == "null" ]; then
            echo "No pude averiguar el genero del nombre."
        else
            echo "El genero de '$nombre' es $genero"
            echo "------------------------------------------"
        fi
    else
        echo "Hubo un error al conectarse a la API."
    fi
done
